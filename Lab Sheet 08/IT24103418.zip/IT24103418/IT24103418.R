#Exercise

#setting the file path
setwd("C:\\Users\\user\\Desktop\\IT24103418")

#importing data set
data<-read.table("Exercise - LaptopsWeights.txt",header=TRUE)

#view dataset in window
fix(data)

#attach dataset
attach(data)

#Question 01

#finding population mean
popmn<-mean(Weight.kg.)

#finding population variance
popvar<-var(Weight.kg.)

#showing population mean and variance
popmn
popvar

#finding population standart deviation and showing it
popsd=sqrt(popvar)
popsd

#Question 02

#creating null vector
samples<-c()

#assigning that n variable
n<-c()

#Draw 25 random samples of size 6 (with replacement)

for(i in 1:25){
  s<-sample(Weight.kg.,6,replace=TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('s',i))
}

colnames(samples)=n

#calculate the samplemean and sample standard deviation for each sample.
s.mean<-apply(samples,2,mean)
s.vars<-apply(samples,2,var)
s.mean
s.vars

s.sd<-sqrt(s.vars)
s.sd

#Question 03

#Calculate the mean and standard deviation of the 25 sample

samplemean<-mean(s.mean)
samplevars<-var(s.mean)
samplemean
samplevars

samplesd<-sqrt(samplevars)
samplesd

#means and state the relationship of them with true mean and true standard deviation.

popmn
samplemean

truevr<-popsd/sqrt(6)
samplesd

